import { Component } from '@angular/core';

@Component({
  selector: 'app-drag-tool',
  templateUrl: './drag-tool.component.html',
  styleUrls: ['./drag-tool.component.scss']
})
export class DragToolComponent {

}
